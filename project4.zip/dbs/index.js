var async = require('async');
var MongoClient = require('mongodb').MongoClient;

let url = "mongodb://localhost:27017";

let dbname = "BlogServer";
 
// Note: A production application should not expose database credentials in plain text.
// For strategies on handling credentials, visit 12factor: https://12factor.net/config.
var BLOG_URI = url+"/"+dbname;
 
var databases = {
  blog: async.apply(MongoClient.connect, BLOG_URI),
};
 
module.exports = function (cb) {
  async.parallel(databases, cb);
};
