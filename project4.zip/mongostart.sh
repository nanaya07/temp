sudo mongod --fork --logpath /var/log/mongodb/mongodb.log
