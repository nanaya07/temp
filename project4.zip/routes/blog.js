var express = require('express');
var commonmark = require('commonmark');

var assert = require('assert');

var router = express.Router();

var reader = new commonmark.Parser();
var writer = new commonmark.HtmlRenderer();

function transform(text) {

    //render commonmark
    let parsed = reader.parse(text);
    // transform parsed if you like...
    let result = writer.render(parsed);
    
    return result;
}

/* GET home page. */
router.get('/:username/:postid', function(req, res, next) {
  let user = req.params.username;
  let pid = parseInt(req.params.postid);

  let pooling_db = req.app.get('pooling_db');
  let collection = pooling_db.collection('Posts');
  let query = {username: user, postid: pid};

  // Find some documents
  collection.find(query).toArray(function(err, docs) {
    assert.equal(err, null);
    console.log("Found the following records");
    console.log(docs);

    //post that we want
    let p = docs[0];

    //date transforming
    let created = new Date(p.created);
    let modified = new Date(p.modified);

    // transform parsed if you like... 
    let resultt = transform(p.title);
    let resultb = transform(p.body);

    res.render('apost', {postid: p.postid, 
			 created: created, 
			 modified: modified ,
			 title: resultt, 
			 body: resultb}, function(err, html) {
      res.send(html);});
  });
});

router.get('/:username', function(req, res, next) {
  let user = req.params.username;
  let pid = 1;

  if (req.query.start) {
    pid = parseInt(req.query.start);
  }

  console.log("pid:"+pid);

  let pooling_db = req.app.get('pooling_db');
  let collection = pooling_db.collection('Posts');
  let query = {username: user, postid: {$gte: pid}};

  // Find some documents
  collection.find(query).limit(6).toArray(function(err, docs) {
    assert.equal(err, null);
    console.log("Found the following records");
    console.log(docs);


    for(let i = 0; i < docs.length; i++) {
      let p = docs[i];

      //date transforming
      docs[i].created = new Date(p.created);
      docs[i].modified = new Date(p.modified);

      // transform parsed if you like...
      docs[i].title = transform(p.title);
      docs[i].body = transform(p.body);
    }

    let next = -1;
    if(docs.length > 5) {
      next = pid + 5;
    }

    res.render('posts', {title: 'posts', posts: docs, current: pid, next: next}, function(err, html) {
      res.send(html);}); 
  });

});

module.exports = router;
