var express = require('express');
var assert = require('assert');
var jwt = require('jsonwebtoken');
var router = express.Router();

function isJSON(json) {
  console.log("isJson");
  if(typeof json =='object')
  {
    // It is JSON
    return true;
  }
  else
  {
    return false;
  }
}
router.use('/:username', function (req, res, next) {
  //authentication
  console.log("start authentication");
  if(!req.cookies.jwt) {
    res.sendStatus(401);
    return;
  }

  let token = req.cookies.jwt;
  let secret_key = "C-UFRaksvPKhx1txJYFcut3QGxsafPmwCY6SCly3G6c";

  let current_time = new Date().getTime() / 1000;
  if(current_time > token.exp) { 
    res.sendStatus(401);
    return; 
  }
  try {
    jwt.verify(token, secret_key, function(err, decoded) {
      console.log(decoded);
      if(decoded.usr == req.params.username) {
        console.log("verified");
        next();
      }
      //unauth
      else {
        console.log("cannot verify");
        res.sendStatus(401);
        return;
      } 
    });
  } catch(err) {
    console.log("Error verify");
    res.sendStatus(401);
    return;
  }
});
/* GET home page. */
router.get('/:username', function(req, res, next) {
  let user = req.params.username;

  let pooling_db = req.app.get('pooling_db');
  let collection = pooling_db.collection('Posts');
  let query = {username: user};

  // Find some documents
  collection.find(query).toArray(function(err, docs) {
    assert.equal(err, null);
    console.log("Found the following records");
    console.log(docs);

    res.status(200).send(docs);
  });
});

router.get('/:username/:postid', function(req, res, next) {
  let user = req.params.username;
  let pid = parseInt(req.params.postid);

  if(isNaN(pid)) {
    res.sendStatus(400);
    return;
  }

  let pooling_db = req.app.get('pooling_db');
  let collection = pooling_db.collection('Posts');
  let query = {username: user, postid: pid};

  // Find some documents
  collection.find(query).toArray(function(err, docs) {
    assert.equal(err, null);
    console.log("Found the following records");
    console.log(docs);

    //post that we want
    if(docs.length == 1) {
      let p = docs[0];
      res.status(200).json({"title": p.title,
                            "body": p.body,
                            "created": p.created,
                            "modified": p.modified});
    }
    else {
      res.sendStatus(404);
    }
  });
});

router.post('/:username/:postid', function(req, res, next) {
  let user = req.params.username;
  let pid = parseInt(req.params.postid);

  if(isNaN(pid)) {
    res.sendStatus(400);
    return;
  }

  let pooling_db = req.app.get('pooling_db');
  let collection = pooling_db.collection('Posts');
  let query = {username: user, postid: pid};

  // Find some documents
  collection.find(query).toArray(function(err, docs) {
    assert.equal(err, null);
    console.log("Found the following records");
    console.log(docs);

    //exist
    if(docs.length > 0) {
      res.sendStatus(400);
    }
    //insert
    else {
      console.log("entry");
      if(isJSON(req.body)) {
        console.log("parse body");
        let title = req.body.title;
        let body = req.body.body;

        let c = new Date();
        let current = c.getTime();

        let entry = {"postid": pid,
                     "username":user,
                     "title": title,
                     "body": body,
                     "created": current,
                     "modified": current};

        console.log(entry);

        collection.insertOne(entry, function(err, r) {
          assert.equal(null, err);
          if(1 == r.insertedCount) {
            res.sendStatus(201); 
          }
          else {
            console.log("bad insert");
            res.sendStatus(400);
          }
        });
      }
      else {
        console.log("not JSON");
        res.sendStatus(400);
      }
    }
  });
});

router.put('/:username/:postid', function(req, res, next) {
  let user = req.params.username;
  let pid = parseInt(req.params.postid);

  if(isNaN(pid)) {
    console.log("Bad pid:"+pid);
    res.sendStatus(400);
    return;
  }

  let pooling_db = req.app.get('pooling_db');
  let collection = pooling_db.collection('Posts');

  let query = {username: user, postid: pid};

  if(isJSON(req.body)) {
    let title = req.body.title;
    let body = req.body.body;
    let c = new Date();
    let current = c.getTime();

    let update_set = {$set: {title: title, body: body, modified: current}};

    // Find some documents
    collection.updateOne(query, update_set, function(err, r) {
      assert.equal(err, null);

      //post that we want
      if(r.matchedCount == 1 && r.modifiedCount == 1) {
        res.sendStatus(200);
      }
      else {
        console.log("Bad update");
        res.sendStatus(400);
      }
    });
  }
  else {
    console.log("Bad body");
    res.sendStatus(400);
  }
});

router.delete('/:username/:postid', function(req, res, next) {
  let user = req.params.username;
  let pid = parseInt(req.params.postid);

  if(isNaN(pid)) {
    res.sendStatus(400);
    return;
  }

  let pooling_db = req.app.get('pooling_db');
  let collection = pooling_db.collection('Posts');

  let query = {username: user, postid: pid};

  collection.deleteOne(query, function(err, r) {
    assert.equal(err, null);

    if(r.deletedCount == 1) {
      res.sendStatus(204);
    }
    else {
      res.sendStatus(400);
    }
  });
});

module.exports = router;
