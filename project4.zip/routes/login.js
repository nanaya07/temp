var express = require('express');
var assert = require('assert');
var bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');

var router = express.Router();

let secret_key = "C-UFRaksvPKhx1txJYFcut3QGxsafPmwCY6SCly3G6c";

/* GET home page. */
router.get('/', function(req, res, next) {
  if((!req.query.username) || (!req.query.password)) {
    res.render('loginform', {reason: "username or password is missing"}, function(err, html) {
      res.send(html);});
    return;
  }

  let username = req.query.username;
  let password = req.query.password;
  let redirect = req.query.redirect;

  let pooling_db = req.app.get('pooling_db');
  let collection = pooling_db.collection('Users');

  let query = {username: username};

  // Find some documents
  collection.find(query).toArray(function(err, docs) {
    assert.equal(err, null);
    console.log("Found the following records");
    console.log(docs);

    //post that we want
    let p = docs[0];

    // Load hash from your password DB.
    bcrypt.compare(password, p.password, function(err, result) {
      // result == true
      console.log(result);
      if(result == true) {
        //generate jwt
        let token = jwt.sign({
		"exp": Math.floor(Date.now() / 1000) + (60 * 60 * 2),
		"usr": username}, secret_key);

        //console.log(token);
        //var decoded = jwt.decode(token, {complete: true});
        //set cookie
        res.cookie('jwt',token);
        //redirect
        res.redirect(redirect);
      }
      else {
        res.render('loginform', {reason: "username and password are not matched"}, function(err, html) {
          res.send(html);});
      }
    });
  });
});

module.exports = router;
