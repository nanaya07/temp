sudo mongod --shutdown
