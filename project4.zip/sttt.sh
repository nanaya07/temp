cd ~/blog-server/
npm start &
cd ~/angular-blog/
ng serve --host 0.0.0.0 &
