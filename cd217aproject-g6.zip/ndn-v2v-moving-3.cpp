#include "ns3/core-module.h"

#include "ns3/mobility-module.h"
#include "ns3/network-module.h"
#include "ns3/wifi-module.h"
#include "ns3/random-variable-stream.h"
#include "ns3/ndnSIM/apps/ndn-producer.hpp"
#include "ns3/ndnSIM/apps/ndn-consumer-cbr.hpp"
#include "ns3/ndnSIM/apps/ndn-app.hpp"
#include "ns3/ndnSIM/helper/ndn-app-helper.hpp"
#include "ns3/ndnSIM/helper/ndn-stack-helper.hpp"
#include <ns3/ndnSIM/helper/ndn-global-routing-helper.hpp>
#include "ns3/animation-interface.h"

#include "ns3/ndnSIM/apps/ndn-consumer-v2v.hpp"
#include "ns3/ndnSIM/apps/custom-app.hpp"

#include <algorithm>
#include <vector>

namespace ns3{

/**
 * This scenario simulates a scenario with 5 cars moving and communicating
 * in an ad-hoc way.
 * 
 * To enable ad-hoc communication, comment out following code in /NFD/deamon/fw/Forwarder.cpp
 * under onIncomingData(Face& inFace, const Data& data)
 *
 *   if (pendingDownstream->getId() == inFace.getId() &&
 *       pendingDownstream->getLinkType() != ndn::nfd::LINK_TYPE_AD_HOC) {
 *     continue;
 *   }
 *
 * This will enable an app can send data back to same face which it get an interest
 *
 * 1 consumer(id:4) request data from producer with frequency 1 interest per second
 * (interests contain constantly increasing sequence number).
 * 1 producer(id:0) provides data to corresponding incoming interests
 *
 * For every received interest, producer replies with a data packet, containing
 * 1024 bytes of payload.
 *
 * To run scenario and see what is happening, use the following command:
 *
 *     NS_LOG=ndn.Consumer:ndn.Producer:ndn.Consumerv2v ./waf --run=ndn-v2v-moving-3
 * (V2VMoving) will show node mobility
 *
 * To modify the mobility model, see function installMobility.
 * To modify the wifi model, see function installWifi.
 * To modify the NDN settings, see function installNDN and for consumer and
 * producer settings, see functions installConsumer and installProducer
 * respectively.
 */

NS_LOG_COMPONENT_DEFINE ("V2VMoving");

//number of nodes that can be modified
static const uint32_t numNodes = 5;

void printPosition(Ptr<const MobilityModel> mobility) //DEBUG purpose
{
  Simulator::Schedule(Seconds(1), &printPosition, mobility);
  NS_LOG_INFO("Car "<<  mobility->GetObject<Node>()->GetId() << " is at: " <<mobility->GetPosition());
}


void installMobility(NodeContainer &c, int simulationEnd)
{
  MobilityHelper mobility;
  mobility.SetMobilityModel("ns3::WaypointMobilityModel");
  mobility.Install(c);

  /* moving scenario controller
   * 0: All node stays in same positon
   * 1: All node moves with same speed 
   * 2: All node moves with same speed but changes to opposite direction when it get half
   * 3: All node moves with different speed within origin positon //default for this example
   */
  int test = 3;
  //distance between nodes at setup
  int node_dis = 10;
  //farthest position that nodes goes
  int fart = 200;
  //range for random movement
  int rang = 50;

  //All node stays in same positon
  if(test == 0){
    Ptr<WaypointMobilityModel> wayMobility[numNodes];
    for (uint32_t i = 0; i < numNodes; i++) {
      wayMobility[i] = c.Get(i)->GetObject<WaypointMobilityModel>();
      Waypoint waypointStart(Seconds(0), Vector3D(i*node_dis, 0, 0));
      Waypoint waypointEnd(Seconds(simulationEnd), Vector3D(i*node_dis, 0, 0));

      wayMobility[i]->AddWaypoint(waypointStart);
      wayMobility[i]->AddWaypoint(waypointEnd);
      NS_LOG_INFO("Node " << i << " positions " << waypointStart << " " << waypointEnd);
    }


    return;
  }

  //All node moves with same speed
  else if(test == 1){
    Ptr<WaypointMobilityModel> wayMobility[numNodes];
    for (uint32_t i = 0; i < numNodes; i++) {
      wayMobility[i] = c.Get(i)->GetObject<WaypointMobilityModel>();
      Waypoint waypointStart(Seconds(0), Vector3D(i*node_dis, 0, 0));
      Waypoint waypointEnd(Seconds(simulationEnd), Vector3D(i*node_dis+fart, 0, 0));

      wayMobility[i]->AddWaypoint(waypointStart);
      wayMobility[i]->AddWaypoint(waypointEnd);
      NS_LOG_INFO("Node " << i << " positions " << waypointStart << " " << waypointEnd);
    }

    return;
  }

  //All node moves with same speed but changes to opposite direction when it get half
  else if(test == 2){
    Ptr<WaypointMobilityModel> wayMobility[numNodes];
    for (uint32_t i = 0; i < numNodes; i++) {
      wayMobility[i] = c.Get(i)->GetObject<WaypointMobilityModel>();
      Waypoint waypointStart(Seconds(0), Vector3D(i*node_dis, 0, 0));
      Waypoint waypointMiddle(Seconds(simulationEnd/2), Vector3D(i*node_dis+fart, 0, 0));
      Waypoint waypointEnd(Seconds(simulationEnd), Vector3D(i*node_dis, 0, 0));

      wayMobility[i]->AddWaypoint(waypointStart);
      wayMobility[i]->AddWaypoint(waypointMiddle);
      wayMobility[i]->AddWaypoint(waypointEnd);
      NS_LOG_INFO("Node " << i << " positions " << waypointStart << " " << waypointEnd);
    }


    return;
  }

  //All node moves with different speed within origin positon
  else if(test == 3){
    Ptr<WaypointMobilityModel> wayMobility[numNodes];
    for (uint32_t i = 0; i < numNodes; i++) {

      srand((unsigned)time(0)); 
      int r1 = rand()%rang;
      int r2 = rand()%rang;
      int r3 = rand()%rang; 
      int r4 = rand()%rang;

      wayMobility[i] = c.Get(i)->GetObject<WaypointMobilityModel>();
      Waypoint waypointStart(Seconds(0), Vector3D(i*node_dis, 0, 0));
      Waypoint waypointEnd(Seconds(simulationEnd), Vector3D(i*node_dis, 0, 0));
        
      Waypoint waypoint1(Seconds(simulationEnd/5), Vector3D(i*node_dis+r1, 0, 0));
      Waypoint waypoint2(Seconds((simulationEnd*2)/5), Vector3D(i*node_dis+r2, 0, 0));
      Waypoint waypoint3(Seconds((simulationEnd*3)/5), Vector3D(i*node_dis+r3, 0, 0));
      Waypoint waypoint4(Seconds((simulationEnd*4)/5), Vector3D(i*node_dis+r4, 0, 0));

      wayMobility[i]->AddWaypoint(waypointStart);
      wayMobility[i]->AddWaypoint(waypoint1);
      wayMobility[i]->AddWaypoint(waypoint2);
      wayMobility[i]->AddWaypoint(waypoint3);
      wayMobility[i]->AddWaypoint(waypoint4);
      wayMobility[i]->AddWaypoint(waypointEnd);
      NS_LOG_INFO("Node " << i << " positions "<<
        waypointStart << " " << 
        waypoint1 << " " <<
        waypoint2 << " " <<
        waypoint3 << " " <<
        waypoint4 << " " <<
        waypointEnd);
    }

    return;
  }

  //All node stays in same positon //if condition error
  else{
    Ptr<WaypointMobilityModel> wayMobility[numNodes];
    for (uint32_t i = 0; i < numNodes; i++) {
      wayMobility[i] = c.Get(i)->GetObject<WaypointMobilityModel>();
      Waypoint waypointStart(Seconds(0), Vector3D(i*10, 0, 0));
      Waypoint waypointEnd(Seconds(simulationEnd), Vector3D(i*10, 0, 0));

      wayMobility[i]->AddWaypoint(waypointStart);
      wayMobility[i]->AddWaypoint(waypointEnd);
      NS_LOG_INFO("Node " << i << " positions " << waypointStart << " " << waypointEnd);
    }

    return;
  }
}

void installWifi(NodeContainer &c, NetDeviceContainer &devices)
{
  // Modulation and wifi channel bit rate
  std::string phyMode("OfdmRate24Mbps");

  // Fix non-unicast data rate to be the same as that of unicast
  Config::SetDefault("ns3::WifiRemoteStationManager::NonUnicastMode", StringValue(phyMode));

  WifiHelper wifi;
  wifi.SetStandard(WIFI_PHY_STANDARD_80211a);

  YansWifiPhyHelper wifiPhy = YansWifiPhyHelper::Default();
  wifiPhy.SetPcapDataLinkType(YansWifiPhyHelper::DLT_IEEE802_11_RADIO);

  ////wifi modification
  YansWifiChannelHelper wifiChannel;
  wifiChannel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
  wifiChannel.AddPropagationLoss("ns3::RangePropagationLossModel",
                                 "MaxRange", DoubleValue(19.0));
  wifiChannel.AddPropagationLoss("ns3::NakagamiPropagationLossModel",
                                 "m0", DoubleValue(1.0),
                                 "m1", DoubleValue(1.0),
                                 "m2", DoubleValue(1.0));
  wifiPhy.SetChannel(wifiChannel.Create());

  // Add a non-QoS upper mac
  NqosWifiMacHelper wifiMac = NqosWifiMacHelper::Default();
  // Set it to adhoc mode
  wifiMac.SetType("ns3::AdhocWifiMac");

  // Disable rate control
  wifi.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                               "DataMode", StringValue(phyMode),
                               "ControlMode", StringValue(phyMode));

  devices = wifi.Install(wifiPhy, wifiMac, c);
}

void installNDN(NodeContainer &c)
{
  ndn::StackHelper ndnHelper;
  ndnHelper.SetDefaultRoutes(true);

  ndnHelper.Install(c);
  ndn::StrategyChoiceHelper::InstallAll("/", "/localhost/nfd/strategy/broadcast");

  ///todo add v2v face


}

void installConsumer(NodeContainer &c)
{
  ndn::AppHelper helper("ns3::ndn::ConsumerCbr");
  helper.SetAttribute("Frequency", DoubleValue (1.0));
  helper.SetAttribute("Randomize", StringValue("uniform"));
  helper.SetPrefix("/v2v/test");

  helper.Install(c);
}

void installProducer(NodeContainer &c)
{
  ndn::AppHelper producerHelper("ns3::ndn::Producer");
  producerHelper.SetPrefix("/v2v");

  producerHelper.Install(c.Get(0));
  NS_LOG_INFO("Producer installed on node " << c.Get(0)->GetId());

}

//new app implemented
void installConsumerv2v(NodeContainer &c)
{
  ndn::AppHelper helper("ns3::ndn::Consumerv2v");
  helper.SetAttribute("Frequency", DoubleValue (1.0));
  helper.SetAttribute("Randomize", StringValue("uniform"));
  helper.SetPrefix("/v2v/test");

  helper.Install(c);
}

int main (int argc, char *argv[])
{
  NS_LOG_UNCOND ("V2VTest Simulator");

  //uint32_t numProducer = 1;
  //simulation time
  int simulationEnd = 20;

  NodeContainer c;
  c.Create(numNodes);

  installMobility(c, simulationEnd);

  NetDeviceContainer netDevices;
  installWifi(c, netDevices);

  installNDN(c);

  //setting application (producer, consumer, consumerv2v)
  int producerId = 0;
  NodeContainer producer;
  producer.Add(c.Get(producerId));

  int consumerId = numNodes-1;
  NodeContainer consumer;
  consumer.Add(c.Get(consumerId));

  NodeContainer consumerv2v;
  for(uint32_t i=1; i<numNodes-1; i++){
    consumerv2v.Add(c.Get(i));
  }
  
  installConsumer(consumer);
  installProducer(producer);
  installConsumerv2v(consumerv2v);

  //change to start from 0
  for(uint32_t i=0; i<c.GetN(); i++){
    Simulator::Schedule(Seconds(1), &printPosition, c.Get(i)->GetObject<WaypointMobilityModel>());
  }
 
  Simulator::Stop(Seconds(simulationEnd));

  std::string animFile = "v2v-test.xml";
  AnimationInterface anim(animFile);
  Simulator::Run ();
  return 0;
}
} // namespace ns3

int
main(int argc, char* argv[])
{
  return ns3::main(argc, argv);
}
